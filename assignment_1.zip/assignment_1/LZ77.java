import java.io.*;
import java.util.*;

class LZ77Tag {
    int position, length;
    char nextChar;

    public LZ77Tag(int position, int length, char nextChar) {
        this.position = position;
        this.length = length;
        this.nextChar = nextChar;
    }

    @Override
    public String toString() {
        return position + "," + length + "," + nextChar;
    }

    public static LZ77Tag fromString(String data) {
        String[] parts = data.split(",");
        return new LZ77Tag(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]), parts[2].charAt(0));
    }
}

public class LZ77 {
    private static final String INPUT_FILE = "input.txt";
    private static final String OUTPUT_FILE = "output.txt";
    private static final String CALCULATION_FILE = "calculations.txt";
    private static final int BUFFER_SIZE = 6; 

    private static int calculateBits(int maxValue) {
        int bits = 1;
        while ((1 << bits) <= maxValue) {
            bits++;
        }
        return bits;
    }

    public static void compress() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE));
        BufferedWriter writer = new BufferedWriter(new FileWriter(OUTPUT_FILE));
        BufferedWriter calcWriter = new BufferedWriter(new FileWriter(CALCULATION_FILE));

        String text = reader.readLine();
        reader.close();

        if (text == null || text.isEmpty()) {
            System.out.println("Input file is empty.");
            return;
        }

        int originalSize = text.length() * 8;
        List<LZ77Tag> tags = new ArrayList<>();
        int i = 0, maxPosition = 0, maxLength = 0;

        while (i < text.length()) {
            int matchPos = 0, matchLen = 0;
            String searchBuffer = text.substring(Math.max(0, i - BUFFER_SIZE), i);

            // Finding the longest match in the search buffer
            for (int j = 0; j < searchBuffer.length(); j++) {
                int k = 0;
                while (i + k < text.length() &&
                       j + k < searchBuffer.length() &&
                       searchBuffer.charAt(j + k) == text.charAt(i + k)) {
                    k++;
                }
                if (k > matchLen) {
                    matchLen = k;
                    matchPos = searchBuffer.length() - j;
                }
            }

            // Get the next character after the match
            char nextChar = (i + matchLen < text.length()) ? text.charAt(i + matchLen) : '\0';
            tags.add(new LZ77Tag(matchPos, matchLen, nextChar));
            maxPosition = Math.max(maxPosition, matchPos);
            maxLength = Math.max(maxLength, matchLen);
            i += matchLen + 1;
        }

        // Writing compressed tags
        for (LZ77Tag tag : tags) {
            writer.write(tag + "\n");
        }
        writer.close();

        // Compression statistics
        int positionBits = calculateBits(maxPosition);
        int lengthBits = calculateBits(maxLength);
        int tagSize = positionBits + lengthBits + 8;
        int compressedSize = tags.size() * tagSize;

        calcWriter.write("Original Size: " + originalSize + " bits\n");
        calcWriter.write("Max Position: " + maxPosition + " -> " + positionBits + " bits\n");
        calcWriter.write("Max Length: " + maxLength + " -> " + lengthBits + " bits\n");
        calcWriter.write("Tag Size: " + tagSize + " bits\n");
        calcWriter.write("Compressed Size: " + compressedSize + " bits\n");
        calcWriter.write("Compression Ratio: " + ((double) compressedSize / originalSize) + "\n");
        calcWriter.close();
    }

    public static void decompress() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(OUTPUT_FILE));
        BufferedWriter writer = new BufferedWriter(new FileWriter(INPUT_FILE));
        StringBuilder output = new StringBuilder();

        String line;
        while ((line = reader.readLine()) != null) {
            LZ77Tag tag = LZ77Tag.fromString(line);
            int start = output.length() - tag.position;

            if (tag.position > 0 && start >= 0) {
                for (int j = 0; j < tag.length; j++) {
                    output.append(output.charAt(start + j));
                }
            }

            if (tag.nextChar != '\0') {
                output.append(tag.nextChar);
            }
        }
        reader.close();
        writer.write(output.toString());
        writer.close();
    }

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter your choice:\n1: Compress \n2: Decompress \n3: Exit");
            int choice = scanner.nextInt();

            if (choice == 1) {
                compress();
                System.out.println("Compression Done. Check calculations.txt for details.");
            } else if (choice == 2) {
                decompress();
                System.out.println("Decompression Done.");
            } else if (choice == 3) {
                System.out.println("Thank you for using the program...");
                break;
            } else {
                System.out.println("Invalid choice, try again.");
            }
        }
        scanner.close();
    }
}
