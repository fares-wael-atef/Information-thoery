import java.io.*;
import java.util.*;

class LZ78Tag {
    int index;
    char nextChar;

    public LZ78Tag(int index, char nextChar) {
        this.index = index;
        this.nextChar = nextChar;
    }

    @Override
    public String toString() {
        return "<" + index + ", " + nextChar + ">";
    }
}

public class LZ78 {
    private static final String INPUT_FILE = "input.txt";
    private static final String OUTPUT_BINARY_FILE = "output.bin";
    private static final String DECOMPRESSED_FILE = "decompressed.txt";
    private static final String CALCULATION_FILE = "calculations.txt";
    private static final String TAGS_OUTPUT_FILE = "output_of_compression_tags.txt";

    public static void compress() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(INPUT_FILE));
        String text = reader.readLine();
        reader.close();

        if (text == null || text.isEmpty()) {
            System.out.println("Input file is empty.");
            return;
        }

        int originalSize = text.length() * 8;
        Map<String, Integer> dictionary = new HashMap<>();
        List<LZ78Tag> tags = new ArrayList<>();
        int dictIndex = 1;
        String buffer = "";

        for (char c : text.toCharArray()) {
            String newBuffer = buffer + c;
            if (!dictionary.containsKey(newBuffer)) {
                int index = buffer.isEmpty() ? 0 : dictionary.get(buffer);
                tags.add(new LZ78Tag(index, c));
                dictionary.put(newBuffer, dictIndex++);
                buffer = "";
            } else {
                buffer = newBuffer;
            }
        }

        // Handle remaining buffer
        if (!buffer.isEmpty()) {
            char lastChar = buffer.charAt(buffer.length() - 1);
            String prevBuffer = buffer.substring(0, buffer.length() - 1);
            int index = prevBuffer.isEmpty() ? 0 : dictionary.get(prevBuffer);
            tags.add(new LZ78Tag(index, lastChar));
        }

        // Write tags to text file
        try (BufferedWriter tagsWriter = new BufferedWriter(new FileWriter(TAGS_OUTPUT_FILE))) {
            for (LZ78Tag tag : tags) {
                tagsWriter.write(tag.toString());
                tagsWriter.newLine();
            }
        }

        // Calculate max index
        int maxIndex = tags.stream()
                .mapToInt(tag -> tag.index)
                .max()
                .orElse(0);
        int indexBits = bitsNeeded(maxIndex);
        int tagSize = indexBits + 8;
        int compressedSize = tags.size() * tagSize;

        // Write to binary text file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(OUTPUT_BINARY_FILE))) {
            for (LZ78Tag tag : tags) {
                String indexStr = String.format("%" + indexBits + "s", 
                        Integer.toBinaryString(tag.index)).replace(' ', '0');
                String charStr = String.format("%8s", 
                        Integer.toBinaryString(tag.nextChar & 0xFF)).replace(' ', '0');
                writer.write(indexStr + charStr);
            }
        }

        // Write calculations
        try (BufferedWriter calcWriter = new BufferedWriter(new FileWriter(CALCULATION_FILE))) {
            calcWriter.write("Original Size: " + originalSize + " bits\n");
            calcWriter.write("Max Index Value: " + maxIndex + " -> " + indexBits + " bits\n");
            calcWriter.write("Tag Size: " + indexBits + " + 8 = " + tagSize + " bits\n");
            calcWriter.write("Number of Tags: " + tags.size() + "\n");
            calcWriter.write("Compressed Size: " + compressedSize + " bits\n");
            calcWriter.write("Compression Ratio: " + 
                    String.format("%.2f", (double) compressedSize / originalSize) + "\n");
        }
    }

    public static void decompress() throws IOException {
        StringBuilder binaryData = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(OUTPUT_BINARY_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                binaryData.append(line);
            }
        }

        List<LZ78Tag> tags = new ArrayList<>();
        int pos = 0;
        int indexBits = 4; // Default, will be recalculated from data
        
        // Auto-detect index bits by finding longest index prefix
        int maxIndex = 0;
        while (pos < binaryData.length()) {
            if (binaryData.length() - pos < 8) break;
            String indexStr = binaryData.substring(pos, pos + indexBits);
            int index = Integer.parseInt(indexStr, 2);
            if (index > maxIndex) maxIndex = index;
            pos += indexBits + 8;
        }
        indexBits = bitsNeeded(maxIndex);
        pos = 0;

        while (pos < binaryData.length()) {
            if (binaryData.length() - pos < indexBits + 8) break;
            
            String indexStr = binaryData.substring(pos, pos + indexBits);
            int index = Integer.parseInt(indexStr, 2);
            pos += indexBits;
            
            String charStr = binaryData.substring(pos, pos + 8);
            char nextChar = (char) Integer.parseInt(charStr, 2);
            pos += 8;
            
            tags.add(new LZ78Tag(index, nextChar));
        }

        // Rebuild text
        StringBuilder output = new StringBuilder();
        List<String> dictionary = new ArrayList<>();
        dictionary.add("");

        for (LZ78Tag tag : tags) {
            String entry = (tag.index == 0 ? "" : dictionary.get(tag.index)) + tag.nextChar;
            output.append(entry);
            dictionary.add(entry);
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(DECOMPRESSED_FILE))) {
            writer.write(output.toString());
        }
    }

    private static int bitsNeeded(int number) {
        if (number == 0) return 1;
        return Integer.SIZE - Integer.numberOfLeadingZeros(number);
    }

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Enter your choice:\n1: Compress \n2: Decompress \n3: Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    compress();
                    System.out.println("Compression Done. Check " + TAGS_OUTPUT_FILE + " for tags.");
                    break;
                case 2:
                    decompress();
                    System.out.println("Decompression Done.");
                    break;
                case 3:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }
}