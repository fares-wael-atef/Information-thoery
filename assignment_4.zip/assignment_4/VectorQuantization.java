import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class VectorQuantization {
    private static final double EPSILON = 0.0001; // Convergence threshold

    public static void main(String[] args) {
        try {
            // Get user inputs
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter the path to the RGB image: ");
            String imagePath = scanner.nextLine();
            
            System.out.print("Enter the vector/block size (e.g., 4 for 4x4 blocks): ");
            int blockSize = scanner.nextInt();
            
            System.out.print("Enter the number of vectors in the codebook (K): ");
            int k = scanner.nextInt();
            
            // Process the image
            processImage(imagePath, blockSize, k);
            
            scanner.close();
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void processImage(String imagePath, int blockSize, int k) throws IOException {
        // 1. Read the RGB image and convert it to grayscale
        BufferedImage originalImage = ImageIO.read(new File(imagePath));
        BufferedImage grayscaleImage = convertToGrayscale(originalImage);
        
        String outputDir = "output";
        File outputDirFile = new File(outputDir);
        if (!outputDirFile.exists()) {
            outputDirFile.mkdir();
        }
        
        // Save grayscale image
        File grayscaleFile = new File(outputDir + "/grayscale.png");
        ImageIO.write(grayscaleImage, "png", grayscaleFile);
        
        // 2. Divide the grayscale image into blocks (vectors)
        int width = grayscaleImage.getWidth();
        int height = grayscaleImage.getHeight();
        
        // Ensure dimensions are multiples of blockSize
        int adjustedWidth = width - (width % blockSize);
        int adjustedHeight = height - (height % blockSize);
        
        // Create adjusted grayscale image if needed
        BufferedImage adjustedImage = grayscaleImage;
        if (width != adjustedWidth || height != adjustedHeight) {
            adjustedImage = new BufferedImage(adjustedWidth, adjustedHeight, BufferedImage.TYPE_BYTE_GRAY);
            Graphics2D g = adjustedImage.createGraphics();
            g.drawImage(grayscaleImage, 0, 0, null);
            g.dispose();
            
            // Save adjusted image
            File adjustedFile = new File(outputDir + "/adjusted_grayscale.png");
            ImageIO.write(adjustedImage, "png", adjustedFile);
        }
        
        // Create blocks
        List<double[]> blocks = createBlocks(adjustedImage, blockSize);
        
        // 3. Generate Best "K" Vectors (Codebook) using LBG Algorithm
        List<double[]> codebook = generateCodebook(blocks, k, blockSize);
        
        // 4 & 5. Compress the image by replacing each block with the nearest codebook vector
        int[][] labeledImage = new int[adjustedHeight/blockSize][adjustedWidth/blockSize];
        for (int i = 0; i < adjustedHeight/blockSize; i++) {
            for (int j = 0; j < adjustedWidth/blockSize; j++) {
                int blockIndex = i * (adjustedWidth/blockSize) + j;
                double[] block = blocks.get(blockIndex);
                int nearestVectorIndex = findNearestVector(block, codebook);
                labeledImage[i][j] = nearestVectorIndex;
            }
        }
        
        // 6. Reconstruct the image
        BufferedImage reconstructedImage = reconstructImage(labeledImage, codebook, blockSize, adjustedWidth, adjustedHeight);
        File reconstructedFile = new File(outputDir + "/reconstructed.png");
        ImageIO.write(reconstructedImage, "png", reconstructedFile);
        
        // 7. Calculate Mean Square Error
        double mse = calculateMSE(adjustedImage, reconstructedImage);
        
        // 8. Calculate Compression Ratio
        double originalSize = adjustedWidth * adjustedHeight * 8; // 8 bits per pixel for grayscale
        double compressedSize = (labeledImage.length * labeledImage[0].length * Math.log(k) / Math.log(2)) + 
                                (k * blockSize * blockSize * 8); // labels + codebook
        double compressionRatio = originalSize / compressedSize;
        
        // Generate report
        generateReport(imagePath, blockSize, k, mse, compressionRatio, originalSize, compressedSize, outputDir);
        
        System.out.println("\nProcessing complete! Check the 'output' directory for results.");
        System.out.println("MSE: " + mse);
        System.out.println("Compression Ratio: " + compressionRatio);
    }
    
    private static BufferedImage convertToGrayscale(BufferedImage originalImage) {
        BufferedImage grayscaleImage = new BufferedImage(
            originalImage.getWidth(), originalImage.getHeight(), BufferedImage.TYPE_BYTE_GRAY);
        Graphics g = grayscaleImage.getGraphics();
        g.drawImage(originalImage, 0, 0, null);
        g.dispose();
        return grayscaleImage;
    }
    
    private static List<double[]> createBlocks(BufferedImage image, int blockSize) {
        int width = image.getWidth();
        int height = image.getHeight();
        List<double[]> blocks = new ArrayList<>();
        
        for (int y = 0; y < height; y += blockSize) {
            for (int x = 0; x < width; x += blockSize) {
                double[] block = new double[blockSize * blockSize];
                int idx = 0;
                for (int i = 0; i < blockSize; i++) {
                    for (int j = 0; j < blockSize; j++) {
                        if (y + i < height && x + j < width) {
                            block[idx++] = (image.getRGB(x + j, y + i) & 0xFF);
                        }
                    }
                }
                blocks.add(block);
            }
        }
        
        return blocks;
    }
    
    private static List<double[]> generateCodebook(List<double[]> blocks, int k, int blockSize) {
        // Start with the average of all blocks as first codeword
        double[] initial = new double[blockSize * blockSize];
        for (double[] block : blocks) {
            for (int i = 0; i < block.length; i++) {
                initial[i] += block[i] / blocks.size();
            }
        }
        
        List<double[]> codebook = new ArrayList<>();
        codebook.add(initial);
        
        // LBG Algorithm with splitting
        while (codebook.size() < k) {
            // Split each vector in the codebook
            List<double[]> newCodebook = new ArrayList<>();
            for (double[] codeword : codebook) {
                double[] codeword1 = Arrays.copyOf(codeword, codeword.length);
                double[] codeword2 = Arrays.copyOf(codeword, codeword.length);
                
                for (int i = 0; i < codeword.length; i++) {
                    codeword1[i] *= 1.01; // Add small perturbation
                    codeword2[i] *= 0.99; // Subtract small perturbation
                }
                
                newCodebook.add(codeword1);
                if (newCodebook.size() < k) { // Ensure we don't exceed k
                    newCodebook.add(codeword2);
                }
            }
            
            codebook = newCodebook;
            
            // Refine using k-means iterations
            boolean converged = false;
            while (!converged) {
                // Assign blocks to nearest codewords
                List<List<double[]>> clusters = new ArrayList<>();
                for (int i = 0; i < codebook.size(); i++) {
                    clusters.add(new ArrayList<>());
                }
                
                for (double[] block : blocks) {
                    int nearestIndex = findNearestVector(block, codebook);
                    clusters.get(nearestIndex).add(block);
                }
                
                // Update codewords
                List<double[]> newCodewords = new ArrayList<>();
                for (List<double[]> cluster : clusters) {
                    if (cluster.isEmpty()) {
                        // If cluster is empty, keep the old codeword
                        newCodewords.add(codebook.get(clusters.indexOf(cluster)));
                    } else {
                        // Calculate centroid
                        double[] centroid = new double[blockSize * blockSize];
                        for (double[] block : cluster) {
                            for (int i = 0; i < block.length; i++) {
                                centroid[i] += block[i] / cluster.size();
                            }
                        }
                        newCodewords.add(centroid);
                    }
                }
                
                // Check convergence
                double totalDistance = 0;
                for (int i = 0; i < codebook.size(); i++) {
                    totalDistance += euclideanDistance(codebook.get(i), newCodewords.get(i));
                }
                
                if (totalDistance < EPSILON) {
                    converged = true;
                }
                
                codebook = newCodewords;
            }
        }
        
        return codebook;
    }
    
    private static int findNearestVector(double[] block, List<double[]> codebook) {
        int nearestIndex = 0;
        double minDistance = Double.MAX_VALUE;
        
        for (int i = 0; i < codebook.size(); i++) {
            double distance = euclideanDistance(block, codebook.get(i));
            if (distance < minDistance) {
                minDistance = distance;
                nearestIndex = i;
            }
        }
        
        return nearestIndex;
    }
    
    private static double euclideanDistance(double[] a, double[] b) {
        double sum = 0;
        for (int i = 0; i < a.length; i++) {
            double diff = a[i] - b[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
    
    private static BufferedImage reconstructImage(int[][] labeledImage, List<double[]> codebook, 
                                                int blockSize, int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        
        for (int i = 0; i < labeledImage.length; i++) {
            for (int j = 0; j < labeledImage[0].length; j++) {
                int codewordIndex = labeledImage[i][j];
                double[] codeword = codebook.get(codewordIndex);
                
                int blockStartY = i * blockSize;
                int blockStartX = j * blockSize;
                
                int idx = 0;
                for (int y = 0; y < blockSize; y++) {
                    for (int x = 0; x < blockSize; x++) {
                        if (blockStartY + y < height && blockStartX + x < width) {
                            int pixelValue = (int) Math.round(codeword[idx++]);
                            // Ensure pixel value is in valid range
                            pixelValue = Math.max(0, Math.min(255, pixelValue));
                            int rgb = (pixelValue << 16) | (pixelValue << 8) | pixelValue;
                            image.setRGB(blockStartX + x, blockStartY + y, rgb);
                        }
                    }
                }
            }
        }
        
        return image;
    }
    
    private static double calculateMSE(BufferedImage original, BufferedImage reconstructed) {
        int width = original.getWidth();
        int height = original.getHeight();
        double sum = 0;
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int originalPixel = original.getRGB(x, y) & 0xFF;
                int reconstructedPixel = reconstructed.getRGB(x, y) & 0xFF;
                double diff = originalPixel - reconstructedPixel;
                sum += diff * diff;
            }
        }
        
        return sum / (width * height);
    }
    
    private static void generateReport(String imagePath, int blockSize, int k, double mse, 
                                    double compressionRatio, double originalSize, 
                                    double compressedSize, String outputDir) throws IOException {
        File reportFile = new File(outputDir + "/report.txt");
        PrintWriter writer = new PrintWriter(new FileWriter(reportFile));
        
        writer.println("Vector Quantization Image Compression Report");
        writer.println("===========================================");
        writer.println();
        writer.println("Input Parameters:");
        writer.println("- Original Image: " + imagePath);
        writer.println("- Block Size: " + blockSize + "x" + blockSize);
        writer.println("- Codebook Size (K): " + k);
        writer.println();
        writer.println("Compression Results:");
        writer.println("- Mean Square Error (MSE): " + mse);
        writer.println("- Original Data Size (bits): " + originalSize);
        writer.println("- Compressed Data Size (bits): " + compressedSize);
        writer.println("- Compression Ratio: " + compressionRatio + ":1");
        writer.println();
        writer.println("Notes:");
        writer.println("- Lower MSE indicates better image quality");
        writer.println("- Higher compression ratio indicates better compression");
        writer.println("- Blocking effects may be visible with larger block sizes");
        writer.println();
        writer.println("Files Generated:");
        writer.println("- grayscale.png: Original image converted to grayscale");
        writer.println("- reconstructed.png: Image after compression and decompression");
        
        writer.close();
    }
}