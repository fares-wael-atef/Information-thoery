import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Decoder {
    private HuffmanTree tree;
    private StringBuilder decodedText;
    
    public Decoder() {
        tree = new HuffmanTree();
        decodedText = new StringBuilder();
    }
    
    public String decode(String encodedBits) {
        decodedText.setLength(0);
        tree = new HuffmanTree(); // Reset the tree
        
        int[] index = {0};
        while (index[0] < encodedBits.length()) {
            String symbol = tree.decodeNextSymbol(encodedBits, index);
            if (symbol == null) {
                break;
            }
            decodedText.append(symbol);
        }
        
        return decodedText.toString();
    }
    
    public String decodeFromFile(String inputPath) throws IOException {
        String encodedBits;
        try (BufferedReader reader = new BufferedReader(new FileReader(inputPath))) {
            encodedBits = reader.readLine();
        }
        
        return decode(encodedBits);
    }
    
    public void saveToFile(String outputPath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            writer.write(decodedText.toString());
        }
    }
}