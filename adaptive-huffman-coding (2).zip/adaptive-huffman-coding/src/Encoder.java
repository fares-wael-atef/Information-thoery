import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Encoder {
    private HuffmanTree tree;
    private StringBuilder encodedBits;
    private Map<Character, Integer> frequencyMap;
    
    public Encoder() {
        tree = new HuffmanTree();
        encodedBits = new StringBuilder();
        frequencyMap = new HashMap<>();
    }
    
    public String encode(String input) {
        encodedBits.setLength(0);
        frequencyMap.clear();
        tree = new HuffmanTree(); // Reset the tree
        
        for (char c : input.toCharArray()) {
            // Update frequency map for entropy calculation
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
            
            if (!isCharInTree(c)) {
                // Encode NYT + ASCII
                String nytCode = tree.getCodeForSymbol('\0');
                String asciiCode = tree.getAsciiCode(c);
                encodedBits.append(nytCode).append(asciiCode);
            } else {
                // Encode using current tree
                String code = tree.getCodeForSymbol(c);
                encodedBits.append(code);
            }
            
            // Update the tree
            tree.update(c);
        }
        
        return encodedBits.toString();
    }
    
    private boolean isCharInTree(char c) {
        String code = tree.getCodeForSymbol(c);
        return !code.equals(tree.getCodeForSymbol('\0'));
    }
    
    public void saveToFile(String outputPath) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputPath))) {
            writer.write(encodedBits.toString());
        }
    }
    
    public double calculateEntropy() {
        int totalChars = 0;
        for (int freq : frequencyMap.values()) {
            totalChars += freq;
        }
        
        double entropy = 0.0;
        for (int freq : frequencyMap.values()) {
            double probability = (double) freq / totalChars;
            entropy -= probability * (Math.log(probability) / Math.log(2));
        }
        
        return entropy;
    }
    
    public double calculateAverageCodeLength() {
        if (encodedBits.length() == 0 || frequencyMap.isEmpty()) {
            return 0.0;
        }
        
        int totalChars = 0;
        for (int freq : frequencyMap.values()) {
            totalChars += freq;
        }
        
        return (double) encodedBits.length() / totalChars;
    }
    
    public double calculateCompressionRatio(int originalSize) {
        if (originalSize == 0 || encodedBits.length() == 0) {
            return 0.0;
        }
        
        // Convert bits to bytes (rounded up)
        int encodedBytes = (encodedBits.length() + 7) / 8;
        return (double) originalSize / encodedBytes;
    }
    
    public Map<Character, Integer> getFrequencyMap() {
        return frequencyMap;
    }
    
    public int getEncodedLength() {
        return encodedBits.length();
    }
}