import java.util.Scanner;

/**
 * Utility class for handling manual input for encoding and decoding operations
 */
public class InputHandler {
    private Encoder encoder;
    private Decoder decoder;
    
    public InputHandler() {
        encoder = new Encoder();
        decoder = new Decoder();
    }
    
    /**
     * Handle encoding from user input through the terminal
     */
    public void handleEncodeFromInput() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("\nEncode from Input");
        System.out.println("================");
        System.out.println("Enter the text to encode (press Enter twice to finish):");
        
        StringBuilder input = new StringBuilder();
        String line;
        
        // Read lines until empty line is encountered
        while (!(line = scanner.nextLine()).isEmpty()) {
            input.append(line).append("\n");
        }
        
        // Remove the last newline if present
        if (input.length() > 0 && input.charAt(input.length() - 1) == '\n') {
            input.setLength(input.length() - 1);
        }
        
        // Return if no input
        if (input.length() == 0) {
            System.out.println("No input provided. Returning to menu.");
            return;
        }
        
        // Encode the input
        String encodedBits = encoder.encode(input.toString());
        
        // Display results
        System.out.println("\nEncoding Results:");
        System.out.println("Original text: " + input);
        System.out.println("Original length: " + input.length() + " characters");
        System.out.println("Encoded bits: " + encodedBits);
        System.out.println("Encoded length: " + encodedBits.length() + " bits");
        System.out.println("Compression ratio: " + String.format("%.2f", encoder.calculateCompressionRatio(input.length())));
        System.out.println("Entropy: " + String.format("%.4f", encoder.calculateEntropy()) + " bits/symbol");
        System.out.println("Average code length: " + String.format("%.4f", encoder.calculateAverageCodeLength()) + " bits/symbol");
        
        // Option to save to file
        System.out.print("\nWould you like to save the encoded output to a file? (y/n): ");
        if (scanner.nextLine().trim().equalsIgnoreCase("y")) {
            System.out.print("Enter file path: ");
            String outputPath = scanner.nextLine().trim();
            
            try {
                encoder.saveToFile(outputPath);
                System.out.println("Encoded output saved to: " + outputPath);
            } catch (Exception e) {
                System.err.println("Error saving to file: " + e.getMessage());
            }
        }
    }
    
    /**
     * Handle decoding from user input through the terminal
     */
    public void handleDecodeFromInput() {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("\nDecode from Input");
        System.out.println("================");
        System.out.println("Enter the binary sequence to decode (only 0s and 1s):");
        String encodedBits = scanner.nextLine().trim();
        
        // Validate input contains only 0s and 1s
        if (!encodedBits.matches("[01]+")) {
            System.out.println("Invalid input. The encoded sequence must contain only 0s and 1s.");
            return;
        }
        
        // Decode the input
        String decodedText = decoder.decode(encodedBits);
        
        // Display results
        System.out.println("\nDecoding Results:");
        System.out.println("Encoded length: " + encodedBits.length() + " bits");
        System.out.println("Decoded text: " + decodedText);
        System.out.println("Decoded length: " + decodedText.length() + " characters");
        
        // Option to save to file
        System.out.print("\nWould you like to save the decoded output to a file? (y/n): ");
        if (scanner.nextLine().trim().equalsIgnoreCase("y")) {
            System.out.print("Enter file path: ");
            String outputPath = scanner.nextLine().trim();
            
            try {
                decoder.saveToFile(outputPath);
                System.out.println("Decoded output saved to: " + outputPath);
            } catch (Exception e) {
                System.err.println("Error saving to file: " + e.getMessage());
            }
        }
    }
}