import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Scanner;

public class AdaptiveHuffman {
    private Encoder encoder;
    private Decoder decoder;
    private InputHandler inputHandler;
    
    public AdaptiveHuffman() {
        encoder = new Encoder();
        decoder = new Decoder();
        inputHandler = new InputHandler();
    }
    
    public void encodeFile(String inputPath, String outputPath) throws IOException {
        String inputText = new String(Files.readAllBytes(Paths.get(inputPath)));
        String encodedBits = encoder.encode(inputText);
        encoder.saveToFile(outputPath);
        
        System.out.println("\nEncoding Results:");
        System.out.println("Original size (bytes): " + inputText.length());
        System.out.println("Encoded size (bits): " + encodedBits.length());
        System.out.println("Encoded size (bytes): " + ((encodedBits.length() + 7) / 8));
        System.out.println("Compression ratio: " + String.format("%.2f", encoder.calculateCompressionRatio(inputText.length())));
        System.out.println("Entropy (bits/symbol): " + String.format("%.4f", encoder.calculateEntropy()));
        System.out.println("Average code length (bits/symbol): " + String.format("%.4f", encoder.calculateAverageCodeLength()));
        
        // Display frequency distribution
        System.out.println("\nSymbol Frequency Distribution:");
        Map<Character, Integer> freqMap = encoder.getFrequencyMap();
        for (Map.Entry<Character, Integer> entry : freqMap.entrySet()) {
            char c = entry.getKey();
            String display = (c == '\n' || c == '\r' || c == '\t') ? 
                              "'" + getEscapedChar(c) + "'" : "'" + c + "'";
            System.out.println(display + ": " + entry.getValue());
        }
    }
    
    private String getEscapedChar(char c) {
        switch (c) {
            case '\n': return "\\n";
            case '\r': return "\\r";
            case '\t': return "\\t";
            default: return String.valueOf(c);
        }
    }
    
    public void decodeFile(String inputPath, String outputPath) throws IOException {
        String decodedText = decoder.decodeFromFile(inputPath);
        decoder.saveToFile(outputPath);
        
        System.out.println("\nDecoding Results:");
        System.out.println("Decoded text length: " + decodedText.length() + " characters");
        System.out.println("Decoded output saved to: " + outputPath);
    }
    
    public void verifyEncoding(String originalPath, String decodedPath) throws IOException {
        String originalText = new String(Files.readAllBytes(Paths.get(originalPath)));
        String decodedText = new String(Files.readAllBytes(Paths.get(decodedPath)));
        
        boolean isIdentical = originalText.equals(decodedText);
        System.out.println("\nVerification Results:");
        System.out.println("Original and decoded files are identical: " + isIdentical);
    }
    
    public static void main(String[] args) {
        AdaptiveHuffman adaptiveHuffman = new AdaptiveHuffman();
        Scanner scanner = new Scanner(System.in);
        
        try {
            while (true) {
                System.out.println("\nAdaptive Huffman Coding");
                System.out.println("======================");
                
                System.out.println("\nSelect operation:");
                System.out.println("1. Encode a file");
                System.out.println("2. Decode a file");
                System.out.println("3. Run full cycle (encode, decode, verify)");
                System.out.println("4. Encode from terminal input");
                System.out.println("5. Decode from terminal input");
                System.out.println("6. Run test cases");
                System.out.println("0. Exit");
                System.out.print("Enter your choice (0-6): ");
                
                int choice = Integer.parseInt(scanner.nextLine());
                
                if (choice == 0) {
                    System.out.println("Exiting program. Goodbye!");
                    break;
                }
                
                switch (choice) {
                    case 1:
                        System.out.print("\nEnter input file path: ");
                        String encodeInputPath = scanner.nextLine();
                        System.out.print("Enter output file path: ");
                        String encodeOutputPath = scanner.nextLine();
                        adaptiveHuffman.encodeFile(encodeInputPath, encodeOutputPath);
                        break;
                        
                    case 2:
                        System.out.print("\nEnter encoded file path: ");
                        String decodeInputPath = scanner.nextLine();
                        System.out.print("Enter output file path: ");
                        String decodeOutputPath = scanner.nextLine();
                        adaptiveHuffman.decodeFile(decodeInputPath, decodeOutputPath);
                        break;
                        
                    case 3:
                        System.out.print("\nEnter input file path: ");
                        String inputPath = scanner.nextLine();
                        System.out.print("Enter encoded output file path: ");
                        String encodedPath = scanner.nextLine();
                        System.out.print("Enter decoded output file path: ");
                        String decodedPath = scanner.nextLine();
                        
                        adaptiveHuffman.encodeFile(inputPath, encodedPath);
                        adaptiveHuffman.decodeFile(encodedPath, decodedPath);
                        adaptiveHuffman.verifyEncoding(inputPath, decodedPath);
                        break;
                        
                    case 4:
                        adaptiveHuffman.inputHandler.handleEncodeFromInput();
                        break;
                        
                    case 5:
                        adaptiveHuffman.inputHandler.handleDecodeFromInput();
                        break;
                        
                    case 6:
                        AdaptiveHuffmanTest.main(new String[0]);
                        break;
                        
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
                
                System.out.println("\nPress Enter to continue...");
                scanner.nextLine();
            }
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Error: Invalid input format");
        } finally {
            scanner.close();
        }
    }
}