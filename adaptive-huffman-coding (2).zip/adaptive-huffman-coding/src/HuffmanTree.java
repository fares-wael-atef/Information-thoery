import java.util.HashMap;
import java.util.Map;

public class HuffmanTree {
    private Node root;
    private Node nytNode;
    private int nextOrder;
    private Map<Character, Node> charToNode;
    
    public HuffmanTree() {
        // Initialize with only the NYT node
        nextOrder = 512; // Start with a large value and decrement
        root = new Node(0, nextOrder--);
        root.setNYT(true);
        nytNode = root;
        charToNode = new HashMap<>();
    }
    
    public Node getRoot() {
        return root;
    }
    
    public Node getNYTNode() {
        return nytNode;
    }
    
    public String getCodeForSymbol(char symbol) {
        Node node = charToNode.get(symbol);
        if (node == null) {
            // Symbol not in tree yet, return NYT path
            return getPathToNode(nytNode);
        } else {
            // Symbol exists, return its path
            return getPathToNode(node);
        }
    }
    
    private String getPathToNode(Node node) {
        StringBuilder path = new StringBuilder();
        Node current = node;
        Node parent = current.getParent();
        
        while (parent != null) {
            if (parent.getLeft() == current) {
                path.insert(0, "0");
            } else {
                path.insert(0, "1");
            }
            current = parent;
            parent = current.getParent();
        }
        
        return path.toString();
    }
    
    public void update(char symbol) {
        if (!charToNode.containsKey(symbol)) {
            // New symbol, create a leaf node
            Node leafNode = new Node(symbol, 1, nextOrder--);
            Node oldNYT = nytNode;
            
            // Create a new internal node that will replace the current NYT
            Node newInternal = new Node(1, nextOrder--);
            
            // Create a new NYT node
            Node newNYT = new Node(0, nextOrder--);
            newNYT.setNYT(true);
            
            // Update tree structure
            if (oldNYT == root) {
                root = newInternal;
            } else {
                Node parent = oldNYT.getParent();
                if (parent.getLeft() == oldNYT) {
                    parent.setLeft(newInternal);
                } else {
                    parent.setRight(newInternal);
                }
            }
            
            // Set children of the new internal node
            newInternal.setLeft(newNYT);
            newInternal.setRight(leafNode);
            
            // Update references
            nytNode = newNYT;
            charToNode.put(symbol, leafNode);
            
            // Start updating from the parent of the new leaf
            updateWeights(newInternal.getParent());
        } else {
            // Symbol already exists, increment its weight and update the tree
            Node node = charToNode.get(symbol);
            slideAndIncrement(node);
        }
    }
    
    private void updateWeights(Node node) {
        while (node != null) {
            slideAndIncrement(node);
            node = node.getParent();
        }
    }
    
    private void slideAndIncrement(Node node) {
        // Find the highest-ordered node of the same weight block
        Node highestInBlock = findHighestNodeInBlock(node);
        
        // Swap if necessary
        if (highestInBlock != node && highestInBlock != node.getParent() && 
            node != highestInBlock.getParent()) {
            swapNodes(node, highestInBlock);
        }
        
        // Increment weight
        node.incrementWeight();
    }
    
    private Node findHighestNodeInBlock(Node node) {
        int weight = node.getWeight();
        Node highest = node;
        
        // Do a tree traversal to find the highest-ordered node with the same weight
        return findHighestInSubtree(root, weight, highest);
    }
    
    private Node findHighestInSubtree(Node current, int targetWeight, Node highest) {
        if (current == null) {
            return highest;
        }
        
        // Check if this node has the target weight and a higher order
        if (current.getWeight() == targetWeight && current.getOrder() > highest.getOrder()) {
            highest = current;
        }
        
        // Check left and right subtrees
        Node leftResult = findHighestInSubtree(current.getLeft(), targetWeight, highest);
        if (leftResult.getOrder() > highest.getOrder()) {
            highest = leftResult;
        }
        
        Node rightResult = findHighestInSubtree(current.getRight(), targetWeight, highest);
        if (rightResult.getOrder() > highest.getOrder()) {
            highest = rightResult;
        }
        
        return highest;
    }
    
    private void swapNodes(Node a, Node b) {
        // Get parents
        Node parentA = a.getParent();
        Node parentB = b.getParent();
        
        // Determine which child a and b are
        boolean aIsLeftChild = (parentA.getLeft() == a);
        boolean bIsLeftChild = (parentB.getLeft() == b);
        
        // Swap a and b in their parents
        if (aIsLeftChild) {
            parentA.setLeft(b);
        } else {
            parentA.setRight(b);
        }
        
        if (bIsLeftChild) {
            parentB.setLeft(a);
        } else {
            parentB.setRight(a);
        }
        
        // Update symbols map if these are leaf nodes
        if (a.isLeaf()) {
            charToNode.put(a.getSymbol(), a);
        }
        if (b.isLeaf()) {
            charToNode.put(b.getSymbol(), b);
        }
    }
    
    public String decodeNextSymbol(String bits, int[] index) {
        Node current = root;
        
        while (index[0] < bits.length()) {
            char bit = bits.charAt(index[0]++);
            
            if (bit == '0') {
                current = current.getLeft();
            } else {
                current = current.getRight();
            }
            
            if (current.isNYT()) {
                // Next 8 bits represent ASCII code
                if (index[0] + 8 > bits.length()) {
                    return null; // Not enough bits remaining
                }
                
                int asciiValue = 0;
                for (int i = 0; i < 8; i++) {
                    asciiValue = (asciiValue << 1) | (bits.charAt(index[0]++) - '0');
                }
                
                char newChar = (char) asciiValue;
                update(newChar); // Update the tree with the new symbol
                return String.valueOf(newChar);
            } else if (current.isLeaf()) {
                char symbol = current.getSymbol();
                update(symbol); // Update the tree with this symbol
                return String.valueOf(symbol);
            }
        }
        
        return null; // End of input reached before finding a symbol
    }
    
    public String getAsciiCode(char symbol) {
        StringBuilder binary = new StringBuilder();
        int ascii = (int) symbol;
        
        for (int i = 7; i >= 0; i--) {
            binary.append((ascii >> i) & 1);
        }
        
        return binary.toString();
    }
}