public class Node implements Comparable<Node> {
    private char symbol;
    private int weight;
    private Node left;
    private Node right;
    private Node parent;
    private int order;
    private boolean isNYT;
    
    // Constructor for internal nodes or NYT node
    public Node(int weight, int order) {
        this.weight = weight;
        this.order = order;
        this.isNYT = (weight == 0);
        this.symbol = '\0';
    }
    
    // Constructor for leaf nodes
    public Node(char symbol, int weight, int order) {
        this.symbol = symbol;
        this.weight = weight;
        this.order = order;
        this.isNYT = false;
    }
    
    // Getters and setters
    public char getSymbol() {
        return symbol;
    }
    
    public int getWeight() {
        return weight;
    }
    
    public void incrementWeight() {
        this.weight++;
    }
    
    public Node getLeft() {
        return left;
    }
    
    public void setLeft(Node left) {
        this.left = left;
        if (left != null) {
            left.setParent(this);
        }
    }
    
    public Node getRight() {
        return right;
    }
    
    public void setRight(Node right) {
        this.right = right;
        if (right != null) {
            right.setParent(this);
        }
    }
    
    public Node getParent() {
        return parent;
    }
    
    public void setParent(Node parent) {
        this.parent = parent;
    }
    
    public int getOrder() {
        return order;
    }
    
    public void setOrder(int order) {
        this.order = order;
    }
    
    public boolean isNYT() {
        return isNYT;
    }
    
    public void setNYT(boolean isNYT) {
        this.isNYT = isNYT;
    }
    
    public boolean isLeaf() {
        return left == null && right == null && !isNYT;
    }
    
    @Override
    public int compareTo(Node other) {
        // Compare by weight first
        int weightComparison = Integer.compare(this.weight, other.weight);
        if (weightComparison != 0) {
            return weightComparison;
        }
        // If weights are equal, compare by order (higher order = added earlier)
        return Integer.compare(other.order, this.order);
    }
    
    @Override
    public String toString() {
        if (isNYT) {
            return "NYT(" + weight + ")";
        } else if (isLeaf()) {
            return "'" + symbol + "'(" + weight + ")";
        } else {
            return "Node(" + weight + ")";
        }
    }
}