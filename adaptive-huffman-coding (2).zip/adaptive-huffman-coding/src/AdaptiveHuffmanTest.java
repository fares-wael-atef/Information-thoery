import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class AdaptiveHuffmanTest {
    
    public static void main(String[] args) {
        runTest("Test Case 1: Simple Repeated Pattern", "aabbbccccddddd");
        runTest("Test Case 2: Lorem Ipsum Sample", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.");
    }
    
    private static void runTest(String testName, String text) {
        System.out.println("\n" + testName);
        System.out.println("=".repeat(testName.length()));
        
        try {
            // Create test files
            String inputFilePath = "test_input.txt";
            String encodedFilePath = "test_encoded.txt";
            String decodedFilePath = "test_decoded.txt";
            
            // Write test data
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(inputFilePath))) {
                writer.write(text);
            }
            
            // Initialize Adaptive Huffman components
            Encoder encoder = new Encoder();
            Decoder decoder = new Decoder();
            
            // Encode
            System.out.println("\nOriginal text: " + text);
            System.out.println("Original length: " + text.length() + " characters");
            
            String encoded = encoder.encode(text);
            encoder.saveToFile(encodedFilePath);
            
            System.out.println("Encoded bits: " + encoded);
            System.out.println("Encoded length: " + encoded.length() + " bits");
            System.out.println("Compression ratio: " + String.format("%.2f", encoder.calculateCompressionRatio(text.length())));
            System.out.println("Entropy: " + String.format("%.4f", encoder.calculateEntropy()) + " bits/symbol");
            System.out.println("Average code length: " + String.format("%.4f", encoder.calculateAverageCodeLength()) + " bits/symbol");
            
            // Decode
            String decoded = decoder.decode(encoded);
            decoder.saveToFile(decodedFilePath);
            
            System.out.println("\nDecoded text: " + decoded);
            System.out.println("Decoded length: " + decoded.length() + " characters");
            
            // Verify
            boolean isSuccess = text.equals(decoded);
            System.out.println("\nVerification: " + (isSuccess ? "SUCCESS" : "FAILURE"));
            
            // Clean up files
            Files.deleteIfExists(Paths.get(inputFilePath));
            Files.deleteIfExists(Paths.get(encodedFilePath));
            Files.deleteIfExists(Paths.get(decodedFilePath));
            
        } catch (IOException e) {
            System.err.println("Error during test: " + e.getMessage());
        }
    }
}