import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Utility class to create sample text files for testing the Adaptive Huffman coding
 */
public class CreateTestFiles {
    
    public static void main(String[] args) {
        // Create a variety of test files with different characteristics
        try {
            // Simple repeated pattern
            createTestFile("test1.txt", "aabbbccccddddd");
            
            // Text with many repeated characters
            createTestFile("test2.txt", "AAAAAAABBBBCCCDDDAAAAAAABBBBCCCDDDA");
            
            // English text sample
            createTestFile("test3.txt", 
                "The quick brown fox jumps over the lazy dog. " +
                "The quick brown fox jumps over the lazy dog. " +
                "The quick brown fox jumps over the lazy dog.");
            
            // Mixed case with symbols
            createTestFile("test4.txt",
                "This is a test file for Adaptive Huffman coding algorithm! " +
                "It contains UPPERCASE, lowercase, digits (123456), and special characters: @#$%^&*().");
            
            System.out.println("Test files created successfully!");
            System.out.println("You can use these files to test the Adaptive Huffman coding implementation.");
            
        } catch (IOException e) {
            System.err.println("Error creating test files: " + e.getMessage());
        }
    }
    
    private static void createTestFile(String filename, String content) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write(content);
        }
        System.out.println("Created file: " + filename);
    }
}