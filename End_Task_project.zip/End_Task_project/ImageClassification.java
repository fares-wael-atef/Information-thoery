import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.imageio.ImageIO;

/**
 * End Term Project - Image Classification and Processing
 * This program provides functionality for:
 * 1. Loading and organizing images from different categories
 * 2. Basic image processing (resizing, grayscale conversion)
 * 3. Image classification by folder structure
 * 4. Calculating image similarity
 * 5. Generating statistics about the dataset
 */
public class ImageClassification {

    // Main categories in the dataset
    private static final String[] CATEGORIES = {"Animals", "Faces", "Nature"};
    // Main directories
    private static final String[] DIRECTORIES = {"train", "test"};
    
    // Store statistics about the dataset
    private static Map<String, Integer> statistics = new HashMap<>();
    
    public static void main(String[] args) {
        System.out.println("Starting Image Classification and Processing...");
        
        // Create output directory if it doesn't exist
        new File("output").mkdirs();
        
        // Process the dataset
        processDataset();
        
        // Print statistics
        printStatistics();
        
        try {
            // Example: Process specific images with both RGB and YUV
            File inputFile = new File("train/Animals/image animal 1.jpg");
            
            // Process with RGB
            File rgbOutputFile = new File("output/rgb_animal1.jpg");
            processImage(inputFile, rgbOutputFile, 200, 200, false);
            
            // Process with YUV
            File yuvOutputFile = new File("output/yuv_animal1.jpg");
            BufferedImage yuvImage = convertToYUV(inputFile);
            ImageIO.write(yuvImage, "jpg", yuvOutputFile);
            
            // Compare RGB and YUV processing
            compareRGBandYUV(inputFile);
            
            // Calculate similarity between two images using both techniques
            File image1 = new File("train/Animals/image animal 1.jpg");
            File image2 = new File("train/Animals/image animal 2.jpg");
            System.out.println("RGB Similarity: " + calculateImageSimilarity(image1, image2));
            System.out.println("YUV Similarity: " + calculateYUVSimilarity(image1, image2));
            
            // Generate compression ratio reports
            generateCompressionRatioReport();
            
        } catch (IOException e) {
            System.err.println("Error processing image: " + e.getMessage());
        }
        
        // Copy and organize images by category
        organizeImages();
        
        // Batch process all images in YUV color space with ratio analysis
        try {
            batchProcessToYUV();
            System.out.println("Successfully batch processed all images to YUV");
        } catch (IOException e) {
            System.err.println("Error in batch YUV processing: " + e.getMessage());
        }
        
        // Compress all processed images into a ZIP file
        try {
            compressOutputToZip();
            System.out.println("Successfully compressed output to zip file");
        } catch (IOException e) {
            System.err.println("Error compressing files: " + e.getMessage());
        }
        
        System.out.println("Image Classification and Processing completed successfully!");
    }
    
    /**
     * Process the entire dataset, gathering statistics
     */
    private static void processDataset() {
        // Initialize statistics
        for (String category : CATEGORIES) {
            statistics.put(category, 0);
        }
        
        // Process each directory
        for (String directory : DIRECTORIES) {
            for (String category : CATEGORIES) {
                String path = directory + "/" + category;
                File folder = new File(path);
                
                if (folder.exists() && folder.isDirectory()) {
                    File[] files = folder.listFiles((dir, name) -> 
                            name.toLowerCase().endsWith(".jpg") || 
                            name.toLowerCase().endsWith(".jpeg") || 
                            name.toLowerCase().endsWith(".png"));
                    
                    if (files != null) {
                        statistics.put(category, statistics.get(category) + files.length);
                        System.out.println("Found " + files.length + " images in " + path);
                    }
                } else {
                    System.out.println("Directory not found: " + path);
                }
            }
        }
    }
    
    /**
     * Print statistics about the dataset
     */
    private static void printStatistics() {
        System.out.println("\n--- Dataset Statistics ---");
        int total = 0;
        
        for (String category : CATEGORIES) {
            int count = statistics.get(category);
            total += count;
            System.out.println(category + ": " + count + " images");
        }
        
        System.out.println("Total images: " + total);
    }
    
    /**
     * Process an image - resize and optionally convert to grayscale
     */
    private static void processImage(File input, File output, int width, int height, boolean toGrayscale) 
            throws IOException {
        // Read the input image
        BufferedImage originalImage = ImageIO.read(input);
        
        // Resize the image
        Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resizedBufferedImage = new BufferedImage(width, height, 
                toGrayscale ? BufferedImage.TYPE_BYTE_GRAY : BufferedImage.TYPE_INT_RGB);
        
        Graphics2D g2d = resizedBufferedImage.createGraphics();
        g2d.drawImage(resizedImage, 0, 0, null);
        g2d.dispose();
        
        // Save the processed image
        ImageIO.write(resizedBufferedImage, "jpg", output);
    }
    
    /**
     * Calculate similarity between two images (basic implementation)
     * Returns a value between 0 (completely different) and 1 (identical)
     */
    private static double calculateImageSimilarity(File file1, File file2) throws IOException {
        // Convert both images to grayscale with the same dimensions for comparison
        BufferedImage img1 = ImageIO.read(file1);
        BufferedImage img2 = ImageIO.read(file2);
        
        // Convert to same size for comparison (use the smaller dimensions)
        int width = Math.min(img1.getWidth(), img2.getWidth());
        int height = Math.min(img1.getHeight(), img2.getHeight());
        
        // Create grayscale versions
        BufferedImage gray1 = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        BufferedImage gray2 = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        
        Graphics2D g2d1 = gray1.createGraphics();
        g2d1.drawImage(img1.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);
        g2d1.dispose();
        
        Graphics2D g2d2 = gray2.createGraphics();
        g2d2.drawImage(img2.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);
        g2d2.dispose();
        
        // Compare pixel by pixel
        long diff = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb1 = gray1.getRGB(x, y) & 0xFF;
                int rgb2 = gray2.getRGB(x, y) & 0xFF;
                diff += Math.abs(rgb1 - rgb2);
            }
        }
        
        // Calculate normalized difference (0 = identical, 1 = completely different)
        double maxDiff = width * height * 255.0;
        double similarity = 1.0 - (diff / maxDiff);
        
        return similarity;
    }
    
    /**
     * Organize images by copying them to a structured output directory
     */
    private static void organizeImages() {
        try {
            // Create output directory structure
            Path outputDir = Paths.get("output", "organized");
            Files.createDirectories(outputDir);
            
            for (String category : CATEGORIES) {
                Files.createDirectories(outputDir.resolve(category));
                
                // Gather images from train and test folders
                for (String directory : DIRECTORIES) {
                    Path sourcePath = Paths.get(directory, category);
                    File sourceDir = sourcePath.toFile();
                    
                    if (sourceDir.exists() && sourceDir.isDirectory()) {
                        File[] files = sourceDir.listFiles((dir, name) -> 
                                name.toLowerCase().endsWith(".jpg") || 
                                name.toLowerCase().endsWith(".jpeg") || 
                                name.toLowerCase().endsWith(".png"));
                        
                        if (files != null) {
                            for (File file : files) {
                                // Copy to organized folder
                                Path targetPath = outputDir.resolve(category).resolve(file.getName());
                                Files.copy(file.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);
                            }
                        }
                    }
                }
            }
            
            System.out.println("Images organized successfully in: " + outputDir);
        } catch (IOException e) {
            System.err.println("Error organizing images: " + e.getMessage());
        }
    }
    
    /**
     * Convert an image to YUV color space
     * Returns the YUV image as a BufferedImage for further processing
     */
    private static BufferedImage convertToYUV(File input) throws IOException {
        BufferedImage originalImage = ImageIO.read(input);
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        
        // Create a new image with the same dimensions
        BufferedImage yuvImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color pixel = new Color(originalImage.getRGB(x, y));
                
                // Extract RGB values
                double r = pixel.getRed();
                double g = pixel.getGreen();
                double b = pixel.getBlue();
                
                // Convert to YUV
                double Y = 0.299 * r + 0.587 * g + 0.114 * b;
                double U = 0.492 * (b - Y);
                double V = 0.877 * (r - Y);
                
                // Normalize values to visible range
                int yVal = (int) Math.min(255, Math.max(0, Y));
                int uVal = (int) Math.min(255, Math.max(0, U + 128));
                int vVal = (int) Math.min(255, Math.max(0, V + 128));
                
                // Map YUV components to RGB channels for visualization
                Color yuvPixel = new Color(yVal, uVal, vVal);
                yuvImage.setRGB(x, y, yuvPixel.getRGB());
            }
        }
        
        return yuvImage;
    }
    
    /**
     * Save YUV image to file
     */
    private static void saveYUVImage(BufferedImage yuvImage, File output) throws IOException {
        ImageIO.write(yuvImage, "jpg", output);
    }
    
    /**
     * Calculate similarity between two images using YUV color space
     */
    private static double calculateYUVSimilarity(File file1, File file2) throws IOException {
        // Convert both images to YUV for comparison
        BufferedImage yuvImg1 = convertToYUV(file1);
        BufferedImage yuvImg2 = convertToYUV(file2);
        
        // Use the smaller dimensions for comparison
        int width = Math.min(yuvImg1.getWidth(), yuvImg2.getWidth());
        int height = Math.min(yuvImg1.getHeight(), yuvImg2.getHeight());
        
        // Resize both images to the same dimensions
        BufferedImage scaledYuv1 = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        BufferedImage scaledYuv2 = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        
        Graphics2D g2d1 = scaledYuv1.createGraphics();
        g2d1.drawImage(yuvImg1.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);
        g2d1.dispose();
        
        Graphics2D g2d2 = scaledYuv2.createGraphics();
        g2d2.drawImage(yuvImg2.getScaledInstance(width, height, Image.SCALE_SMOOTH), 0, 0, null);
        g2d2.dispose();
        
        // Compare Y channel (luminance) similarity which is often most important
        // Y is stored in the red channel of our visualization
        long diffY = 0;
        long diffU = 0;
        long diffV = 0;
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color p1 = new Color(scaledYuv1.getRGB(x, y));
                Color p2 = new Color(scaledYuv2.getRGB(x, y));
                
                // Extract Y, U, V components (from our visualization they are mapped to R, G, B)
                diffY += Math.abs(p1.getRed() - p2.getRed());          // Y component
                diffU += Math.abs(p1.getGreen() - p2.getGreen());      // U component
                diffV += Math.abs(p1.getBlue() - p2.getBlue());        // V component
            }
        }
        
        // Calculate normalized difference with more weight on Y (luminance)
        double totalPixels = width * height * 255.0;
        double weightedDiff = (0.6 * diffY + 0.2 * diffU + 0.2 * diffV) / 3.0; 
        double similarity = 1.0 - (weightedDiff / totalPixels);
        
        return similarity;
    }
    
    /**
     * Compare RGB and YUV processing techniques
     */
    private static void compareRGBandYUV(File inputFile) throws IOException {
        System.out.println("\n--- RGB vs YUV Comparison ---");
        
        // Get original file size
        long originalSize = inputFile.length();
        System.out.println("Original image size: " + originalSize + " bytes");
        
        // Process with RGB
        File rgbOutputFile = new File("output/rgb_compare.jpg");
        long startTimeRGB = System.currentTimeMillis();
        BufferedImage rgbImage = ImageIO.read(inputFile);
        ImageIO.write(rgbImage, "jpg", rgbOutputFile);
        long rgbProcessingTime = System.currentTimeMillis() - startTimeRGB;
        long rgbOutputSize = rgbOutputFile.length();
        
        // Process with YUV
        File yuvOutputFile = new File("output/yuv_compare.jpg");
        long startTimeYUV = System.currentTimeMillis();
        BufferedImage yuvImage = convertToYUV(inputFile);
        ImageIO.write(yuvImage, "jpg", yuvOutputFile);
        long yuvProcessingTime = System.currentTimeMillis() - startTimeYUV;
        long yuvOutputSize = yuvOutputFile.length();
        
        // Calculate compression ratios
        double rgbCompressionRatio = (double) originalSize / rgbOutputSize;
        double yuvCompressionRatio = (double) originalSize / yuvOutputSize;
        
        // Print results
        System.out.println("RGB Processing:");
        System.out.println("  - Processing time: " + rgbProcessingTime + " ms");
        System.out.println("  - Output size: " + rgbOutputSize + " bytes");
        System.out.println("  - Compression ratio: " + String.format("%.2f", rgbCompressionRatio));
        
        System.out.println("YUV Processing:");
        System.out.println("  - Processing time: " + yuvProcessingTime + " ms");
        System.out.println("  - Output size: " + yuvOutputSize + " bytes");
        System.out.println("  - Compression ratio: " + String.format("%.2f", yuvCompressionRatio));
        
        // Compare quality - use original as reference and calculate PSNR
        double rgbPSNR = calculatePSNR(inputFile, rgbOutputFile);
        double yuvPSNR = calculatePSNR(inputFile, yuvOutputFile);
        
        System.out.println("RGB Quality (PSNR): " + String.format("%.2f", rgbPSNR) + " dB");
        System.out.println("YUV Quality (PSNR): " + String.format("%.2f", yuvPSNR) + " dB");
        
        String conclusion = (yuvCompressionRatio > rgbCompressionRatio) ? 
                "YUV provides better compression" : "RGB provides better compression";
        System.out.println("Conclusion: " + conclusion);
    }
    
    /**
     * Calculate Peak Signal-to-Noise Ratio between original and processed image
     */
    private static double calculatePSNR(File original, File processed) throws IOException {
        BufferedImage originalImg = ImageIO.read(original);
        BufferedImage processedImg = ImageIO.read(processed);
        
        // Resize if needed
        int width = Math.min(originalImg.getWidth(), processedImg.getWidth());
        int height = Math.min(originalImg.getHeight(), processedImg.getHeight());
        
        // Calculate Mean Squared Error
        double mse = 0.0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color origPixel = new Color(originalImg.getRGB(x, y));
                Color procPixel = new Color(processedImg.getRGB(x, y));
                
                int rDiff = origPixel.getRed() - procPixel.getRed();
                int gDiff = origPixel.getGreen() - procPixel.getGreen();
                int bDiff = origPixel.getBlue() - procPixel.getBlue();
                
                mse += (rDiff * rDiff + gDiff * gDiff + bDiff * bDiff);
            }
        }
        
        mse /= (width * height * 3);  // 3 channels (RGB)
        
        // Calculate PSNR
        if (mse == 0) {
            return 100.0;  // Images are identical
        }
        
        // Max value for 8-bit color is 255
        double psnr = 10 * Math.log10((255.0 * 255.0) / mse);
        return psnr;
    }
    
    /**
     * Generate a report comparing compression ratios across the dataset
     */
    private static void generateCompressionRatioReport() throws IOException {
        File reportDir = new File("output/reports");
        reportDir.mkdirs();
        File reportFile = new File(reportDir, "compression_ratio_report.txt");
        
        try (PrintWriter writer = new PrintWriter(reportFile)) {
            writer.println("COMPRESSION RATIO ANALYSIS REPORT");
            writer.println("=================================");
            writer.println();
            
            writer.println("Category\tFile\tOriginal Size (B)\tRGB Size (B)\tYUV Size (B)\tRGB Ratio\tYUV Ratio");
            writer.println("------------------------------------------------------------------------------------");
            
            // Process sample files from each category
            for (String directory : DIRECTORIES) {
                for (String category : CATEGORIES) {
                    Path sourcePath = Paths.get(directory, category);
                    File sourceDir = sourcePath.toFile();
                    
                    if (sourceDir.exists() && sourceDir.isDirectory()) {
                        File[] files = sourceDir.listFiles((dir, name) -> 
                                name.toLowerCase().endsWith(".jpg") || 
                                name.toLowerCase().endsWith(".jpeg") || 
                                name.toLowerCase().endsWith(".png"));
                        
                        if (files != null && files.length > 0) {
                            // Process up to 3 sample files from this category
                            int sampleCount = Math.min(3, files.length);
                            for (int i = 0; i < sampleCount; i++) {
                                File origFile = files[i];
                                long origSize = origFile.length();
                                
                                // Process with RGB
                                File rgbOutput = new File("output/reports/rgb_" + category + "_" + i + ".jpg");
                                BufferedImage rgbImage = ImageIO.read(origFile);
                                ImageIO.write(rgbImage, "jpg", rgbOutput);
                                long rgbSize = rgbOutput.length();
                                
                                // Process with YUV
                                File yuvOutput = new File("output/reports/yuv_" + category + "_" + i + ".jpg");
                                BufferedImage yuvImage = convertToYUV(origFile);
                                ImageIO.write(yuvImage, "jpg", yuvOutput);
                                long yuvSize = yuvOutput.length();
                                
                                // Calculate ratios
                                double rgbRatio = (double) origSize / rgbSize;
                                double yuvRatio = (double) origSize / yuvSize;
                                
                                // Write to report
                                writer.printf("%s\t%s\t%d\t%d\t%d\t%.2f\t%.2f%n", 
                                        category, origFile.getName(), origSize, rgbSize, yuvSize, 
                                        rgbRatio, yuvRatio);
                            }
                        }
                    }
                }
            }
            
            writer.println();
            writer.println("SUMMARY");
            writer.println("=======");
            writer.println("Compression ratio > 1.0 means the file size was reduced");
            writer.println("Higher ratio means better compression");
            writer.println();
            writer.println("YUV color space typically has advantages for compression because:");
            writer.println("1. It separates luminance (Y) from chrominance (U, V)");
            writer.println("2. Human vision is more sensitive to luminance than chrominance");
            writer.println("3. This allows more aggressive compression of chrominance channels");
        }
        
        System.out.println("Compression ratio report generated: " + reportFile.getPath());
    }
    
    /**
     * BONUS: Batch process all images to YUV color space
     */
    private static void batchProcessToYUV() throws IOException {
        // Create output directory for YUV images
        Path yuvOutputDir = Paths.get("output", "yuv");
        Files.createDirectories(yuvOutputDir);
        
        // Create a report file for YUV processing
        File reportFile = new File("output/yuv_processing_report.txt");
        try (PrintWriter writer = new PrintWriter(reportFile)) {
            writer.println("YUV PROCESSING REPORT");
            writer.println("====================");
            writer.println("File\tOriginal Size (B)\tYUV Size (B)\tCompression Ratio\tProcessing Time (ms)");
            writer.println("-----------------------------------------------------------------------------");
            
            // Process each category
            for (String directory : DIRECTORIES) {
                for (String category : CATEGORIES) {
                    // Create category directory
                    Files.createDirectories(yuvOutputDir.resolve(category));
                    
                    Path sourcePath = Paths.get(directory, category);
                    File sourceDir = sourcePath.toFile();
                    
                    if (sourceDir.exists() && sourceDir.isDirectory()) {
                        File[] files = sourceDir.listFiles((dir, name) -> 
                                name.toLowerCase().endsWith(".jpg") || 
                                name.toLowerCase().endsWith(".jpeg") || 
                                name.toLowerCase().endsWith(".png"));
                        
                        if (files != null) {
                            for (File file : files) {
                                // Measure original size
                                long originalSize = file.length();
                                
                                // Convert to YUV
                                long startTime = System.currentTimeMillis();
                                BufferedImage yuvImage = convertToYUV(file);
                                
                                // Save the YUV image
                                File outputFile = yuvOutputDir.resolve(category)
                                        .resolve("yuv_" + file.getName()).toFile();
                                ImageIO.write(yuvImage, "jpg", outputFile);
                                
                                long processingTime = System.currentTimeMillis() - startTime;
                                long yuvSize = outputFile.length();
                                double compressionRatio = (double) originalSize / yuvSize;
                                
                                // Write to report
                                writer.printf("%s\t%d\t%d\t%.2f\t%d%n", 
                                        file.getName(), originalSize, yuvSize, 
                                        compressionRatio, processingTime);
                            }
                        }
                    }
                }
            }
            
            writer.println("\nSUMMARY STATISTICS FOR YUV PROCESSING");
            writer.println("==================================");
            writer.println("YUV color space conversion provides several benefits:");
            writer.println("1. Better compression potential due to separation of luminance and chrominance");
            writer.println("2. More aligned with human visual perception");
            writer.println("3. Often used in video compression standards like H.264 and HEVC");
        }
        
        System.out.println("YUV processing report generated: " + reportFile.getPath());
    }
    
    /**
     * BONUS: Compress all files in output directory to a ZIP file
     */
    private static void compressOutputToZip() throws IOException {
        File outputDir = new File("output");
        File zipFile = new File("output/all_processed_images.zip");
        
        // Create list to store files to be added to zip
        List<File> filesToZip = new ArrayList<>();
        collectFilesToZip(outputDir, filesToZip);
        
        // Create ZIP file
        try (FileOutputStream fos = new FileOutputStream(zipFile);
             ZipOutputStream zos = new ZipOutputStream(fos)) {
            
            // Get base path for relative paths in zip
            Path basePath = outputDir.toPath();
            
            // Add files to ZIP
            for (File file : filesToZip) {
                // Skip the zip file itself
                if (file.equals(zipFile)) {
                    continue;
                }
                
                // Create relative path within the zip
                Path relativePath = basePath.relativize(file.toPath());
                ZipEntry zipEntry = new ZipEntry(relativePath.toString());
                zos.putNextEntry(zipEntry);
                
                // Only add file content if it's a file (not a directory)
                if (file.isFile()) {
                    byte[] bytes = Files.readAllBytes(file.toPath());
                    zos.write(bytes);
                }
                
                zos.closeEntry();
            }
        }
    }
    
    /**
     * Helper method to recursively collect files for zipping
     */
    private static void collectFilesToZip(File directory, List<File> fileList) {
        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                fileList.add(file);
                if (file.isDirectory()) {
                    collectFilesToZip(file, fileList);
                }
            }
        }
    }
}